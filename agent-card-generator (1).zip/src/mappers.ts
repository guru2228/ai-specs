export function coalesce<T>(...vals: Array<T | undefined | null>): T | undefined {
  for (const v of vals) if (v !== undefined && v !== null) return v;
  return undefined;
}
const FORMAT_TO_MIME: Record<string, string> = {
  text: "text/plain", json: "application/json", xml: "application/xml",
  image: "image/*", audio: "audio/*", video: "video/*", file: "application/octet-stream",
};
export function deriveMimeModes(entries?: Array<{ format?: string; contentTypes?: string[] }>): string[] {
  if (!entries || entries.length === 0) return [];
  const out = new Set<string>();
  for (const e of entries) {
    if (e?.contentTypes?.length) e.contentTypes.forEach(ct => out.add(ct));
    else if (e?.format && FORMAT_TO_MIME[e.format]) out.add(FORMAT_TO_MIME[e.format]);
  }
  return Array.from(out);
}
