export type Transport = "JSONRPC" | "GRPC" | "HTTP+JSON";

export interface AgentCard {
  protocolVersion: string;
  name: string;
  description: string;
  version: string;
  iconUrl?: string;
  documentationUrl?: string;
  provider?: { organization?: string; url?: string };
  preferredInterface: { url: string; transport: Transport };
  additionalInterfaces?: { url: string; transport: Transport }[];
  capabilities?: {
    streaming?: boolean;
    pushNotifications?: boolean;
    stateTransitionHistory?: boolean;
    extensions?: { uri: string; description?: string; required?: boolean; params?: Record<string, unknown> }[];
  };
  securitySchemes?: Record<string, unknown>;
  security?: Record<string, string[]>[];
  defaultInputModes: string[];
  defaultOutputModes: string[];
  skills: Array<{
    id: string;
    name: string;
    description: string;
    tags?: string[];
    examples?: string[];
    inputModes?: string[];
    outputModes?: string[];
    security?: Record<string, string[]>[];
  }>;
  supportsAuthenticatedExtendedCard?: boolean;
  signatures?: Array<Record<string, unknown>>;
}

export interface AgentSpec {
  identity?: { urn?: string; uuid?: string; displayName?: string; icon?: string; version?: string };
  goal?: string; backstory?: string; systemPrompt?: string;
  community?: { docsUrl?: string };
  ownership?: { organization?: string };
  persona?: { topics?: string[] };
  ioConfig?: { inputs?: Array<{ format?: string; contentTypes?: string[] }>; outputs?: Array<{ format?: string; contentTypes?: string[] }>; };
  api?: { endpoints?: Array<{ name: string; method: "GET"|"POST"|"PUT"|"DELETE"|"PATCH"; path: string; streaming?: boolean; contentTypes?: string[] }>; };
  tools?: Array<{ name: string; description?: string; mcp: { serverRef: { urn?: string; uuid?: string }, toolName: string } }>;
  a2a?: { card?: {
    protocolVersion?: string; name?: string; description?: string; version?: string;
    iconUrl?: string; documentationUrl?: string; provider?: { organization?: string; url?: string };
    preferredInterface?: { url: string; transport: Transport };
    additionalInterfaces?: Array<{ url: string; transport: Transport }>;
    capabilities?: { streaming?: boolean; pushNotifications?: boolean; stateTransitionHistory?: boolean; extensions?: { uri: string; description?: string; required?: boolean; params?: Record<string, unknown> }[]; };
    securitySchemes?: Record<string, unknown>; security?: Record<string, string[]>[];
    defaultInputModes?: string[]; defaultOutputModes?: string[]; skills?: AgentCard["skills"];
    supportsAuthenticatedExtendedCard?: boolean; signatures?: AgentCard["signatures"];
  }};
}
