# @sage/agent-card-generator

Generate an **A2A Agent Card** from your Agent CRD YAML.

## Quick use

```bash
pnpm i
pnpm build
node dist/bin/generate-agent-card.js \  -i path/to/agent.yaml \  -o public/.well-known/agent-card.json \  --pretty --strict
```
