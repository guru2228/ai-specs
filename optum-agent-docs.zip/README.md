# Optum Agent & AgentFlow Docs

This repo contains a ready-to-commit **docs/** folder for the Agent and AgentFlow specifications,
a tiny TS **agent-card generator**, and a GitHub Action workflow that lints & generates the A2A Agent Card.
