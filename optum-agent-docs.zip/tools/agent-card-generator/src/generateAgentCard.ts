import type { AgentCard, AgentSpec, Transport } from "./types.js";
import { coalesce, deriveMimeModes } from "./mappers.js";
export function generateAgentCardFromSpec(spec: AgentSpec, opts?: { strict?: boolean }): AgentCard {
  const strict = !!opts?.strict;
  const c = spec?.a2a?.card ?? {};
  const name = coalesce(c.name, spec.identity?.displayName);
  const description = coalesce(c.description, [spec.goal, spec.backstory].filter(Boolean).join(" — ") || undefined);
  const version = coalesce(c.version, spec.identity?.version, "0.1.0");
  const iconUrl = coalesce(c.iconUrl, isUrl(spec.identity?.icon) ? spec.identity?.icon : undefined);
  const documentationUrl = coalesce(c.documentationUrl, spec.community?.docsUrl);
  const provider = coalesce(c.provider, spec.ownership?.organization ? { organization: spec.ownership?.organization } : undefined);
  const protocolVersion = c.protocolVersion ?? "0.3.0";
  const preferredInterface = c.preferredInterface ?? inferPreferredInterface(spec);
  if (strict && !preferredInterface) throw new Error("A2A: preferredInterface is required");
  const defaultInputModes = c.defaultInputModes ?? deriveMimeModes(spec.ioConfig?.inputs) ?? ["application/json"];
  const defaultOutputModes = c.defaultOutputModes ?? deriveMimeModes(spec.ioConfig?.outputs) ?? ["application/json"];
  const streaming = c.capabilities?.streaming ?? !!spec.api?.endpoints?.some(e => e.streaming);
  const capabilities = { streaming, pushNotifications: c.capabilities?.pushNotifications, stateTransitionHistory: c.capabilities?.stateTransitionHistory, extensions: c.capabilities?.extensions };
  const skills = c.skills ?? deriveSkills(spec);
  if (strict) {
    const required = { protocolVersion, name, description, version, preferredInterface, defaultInputModes: defaultInputModes?.length, defaultOutputModes: defaultOutputModes?.length, skills: skills?.length };
    for (const [k,v] of Object.entries(required)) if (!v) throw new Error(`A2A: missing required card field: ${k}`);
  }
  return { protocolVersion, name: name!, description: description!, version: version!, iconUrl, documentationUrl, provider, preferredInterface: preferredInterface!, additionalInterfaces: c.additionalInterfaces, capabilities, securitySchemes: c.securitySchemes, security: c.security, defaultInputModes, defaultOutputModes, skills, supportsAuthenticatedExtendedCard: c.supportsAuthenticatedExtendedCard, signatures: c.signatures };
}
function isUrl(v?: string) { return !!v && /^(https?:)?\/\//.test(v); }
function inferPreferredInterface(spec: AgentSpec): { url: string; transport: Transport } | undefined { return spec.api?.endpoints?.length ? { url: "/", transport: "HTTP+JSON" } : undefined; }
function deriveSkills(spec: AgentSpec): AgentCard["skills"] {
  const tags = spec.persona?.topics ?? [];
  const skills: AgentCard["skills"] = [];
  for (const e of spec.api?.endpoints ?? []) {
    skills.push({ id: `api:${e.name}`, name: e.name, description: `HTTP ${e.method} ${e.path}`, tags, inputModes: e.contentTypes ?? ["application/json"], outputModes: ["application/json"] });
  }
  for (const t of spec.tools ?? []) {
    const id = `tool:${t.mcp?.serverRef?.urn ?? t.mcp?.serverRef?.uuid ?? t.name}`;
    skills.push({ id, name: t.name, description: t.description ?? `Tool ${t.mcp.toolName} via MCP`, tags, inputModes: ["application/json"], outputModes: ["application/json"] });
  }
  return skills;
}
