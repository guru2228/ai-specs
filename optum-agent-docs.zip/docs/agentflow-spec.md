# Optum AgentFlow Specification: A Developer's Guide

Version: 1.0 · Date: August 31, 2025

Covers identity/ownership, participants/inlineOrchestrator, orchestration protocol (A2A/Local),
topology modes (Sequential/Parallel/Hierarchical/Network), variables/artifacts, ops/telemetry/security.
Sample in docs/examples/agentflows/pa-intake-demo.yaml.
