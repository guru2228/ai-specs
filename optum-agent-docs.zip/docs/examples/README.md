# Examples

- Agents → [clinical-summarizer.yaml](./agents/clinical-summarizer.yaml)
- AgentFlows → [pa-intake-demo.yaml](./agentflows/pa-intake-demo.yaml)
