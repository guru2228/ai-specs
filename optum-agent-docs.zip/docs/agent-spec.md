# Optum Agent Specification: A Developer's Guide

Version: 1.0 · Date: August 31, 2025

See sections: ownership, identity, context, persona, ioConfig, behavior, llmGateways & llm,
mcpServers & tools, knowledgeBases & rag, api, a2a.card, stateManagement, secretsProvider,
security/ops/telemetry/evaluation/community. Sample spec in docs/examples/agents/clinical-summarizer.yaml.
