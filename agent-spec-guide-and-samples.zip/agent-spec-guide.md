# Agent Spec Guide (v1alpha9)

See in-chat guide for the full version. This file accompanies sample specs.
