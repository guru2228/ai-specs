# @sage/agent-card-generator

A tiny TypeScript utility to **generate an A2A Agent Card** from your Agent CRD YAML (the spec we designed) and optionally expose it via a **Next.js /.well-known route**.

## Install

```bash
pnpm add -D @sage/agent-card-generator
# or
npm i -D @sage/agent-card-generator
```

> This repo ships as TS; run `pnpm build` to emit `dist/`.

## CLI

```bash
pnpm build
node dist/bin/generate-agent-card.js   -i path/to/agent.yaml   -o public/.well-known/agent-card.json   --pretty
```

Flags:
- `-i, --input`    Path to CRD YAML (required)
- `-o, --output`   Where to write `agent-card.json` (required)
- `--pretty`       Pretty-print JSON
- `--strict`       Fail if required A2A fields are missing

## Library

```ts
import { generateAgentCardFromSpec } from "@sage/agent-card-generator";

const crd = /* load YAML & parse */;
const card = generateAgentCardFromSpec(crd.spec, { strict: true });
console.log(JSON.stringify(card, null, 2));
```

## Next.js Route (App Router)

This example serves a live card from `config/agent.yaml`:

`app/.well-known/agent-card.json/route.ts`:

```ts
export const runtime = "nodejs";
import { NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import YAML from "yaml";
import { generateAgentCardFromSpec } from "@sage/agent-card-generator";

export async function GET() {
  try {
    const path = process.env.AGENT_SPEC_PATH || process.cwd() + "/config/agent.yaml";
    const raw = await readFile(path, "utf8");
    const crd = YAML.parse(raw);
    const card = generateAgentCardFromSpec(crd.spec, { strict: true });
    return new NextResponse(JSON.stringify(card), {
      headers: {
        "content-type": "application/json",
        "cache-control": "public, max-age=300, stale-while-revalidate=86400"
      }
    });
  } catch (err: any) {
    return new NextResponse(JSON.stringify({ error: err?.message || "failed to generate agent card" }), { status: 500 });
  }
}
```

Or, generate at build-time into `public/.well-known/agent-card.json` using the CLI.

## Mapping Philosophy

- `identity.displayName|version|icon` → `name|version|iconUrl`
- `goal/backstory/systemPrompt` → `description`
- `community.docsUrl` → `documentationUrl`
- `a2a.card.preferredInterface(+additionalInterfaces)` → interface URLs & transports
- `ioConfig.inputs/outputs.contentTypes` → `defaultInputModes|defaultOutputModes`
- `api.endpoints|tools` → `skills[]`
- `a2a.card.securitySchemes/security` → pass-through to card

See `src/generateAgentCard.ts` for details and heuristics.