import type { AgentCard, AgentSpec, Transport } from "./types.js";
import { coalesce, deriveMimeModes, ensureHttps } from "./mappers.js";

/**
 * Generate an A2A Agent Card from our CRD spec.
 * Throws if strict=true and required fields cannot be satisfied.
 */
export function generateAgentCardFromSpec(spec: AgentSpec, opts?: { strict?: boolean }): AgentCard {
  const strict = !!opts?.strict;
  const c = spec?.a2a?.card ?? {};

  const name = coalesce(c.name, spec.identity?.displayName);
  const description = coalesce(
    c.description,
    [spec.goal, spec.backstory].filter(Boolean).join(" — ") || undefined
  );
  const version = coalesce(c.version, spec.identity?.version, "0.1.0");
  const iconUrl = coalesce(c.iconUrl, isProbablyUrl(spec.identity?.icon) ? spec.identity?.icon : undefined);
  const documentationUrl = coalesce(c.documentationUrl, spec.community?.docsUrl);
  const provider = coalesce(c.provider, spec.ownership?.organization ? { organization: spec.ownership?.organization } : undefined);
  const protocolVersion = c.protocolVersion ?? "0.3.0";

  const preferredInterface = c.preferredInterface ?? inferPreferredInterface(spec);
  if (strict && !preferredInterface) {
    throw new Error("A2A: preferredInterface is required (set spec.a2a.card.preferredInterface).");
  }

  const additionalInterfaces = c.additionalInterfaces;

  const defaultInputModes =
    c.defaultInputModes ?? deriveMimeModes(spec.ioConfig?.inputs) ?? ["application/json"];
  const defaultOutputModes =
    c.defaultOutputModes ?? deriveMimeModes(spec.ioConfig?.outputs) ?? ["application/json"];

  const streaming = c.capabilities?.streaming ?? !!spec.api?.endpoints?.some(e => e.streaming);
  const capabilities = {
    streaming,
    pushNotifications: c.capabilities?.pushNotifications,
    stateTransitionHistory: c.capabilities?.stateTransitionHistory,
    extensions: c.capabilities?.extensions
  };

  const securitySchemes = c.securitySchemes;
  const security = c.security;

  const skills = c.skills ?? deriveSkills(spec);

  if (strict) {
    for (const [key, val] of Object.entries({
      protocolVersion,
      name,
      description,
      version,
      preferredInterface,
      defaultInputModes: defaultInputModes?.length,
      defaultOutputModes: defaultOutputModes?.length,
      skills: skills?.length
    })) {
      if (!val) throw new Error(`A2A: missing required card field: ${key}`);
    }
  }

  const card: AgentCard = {
    protocolVersion,
    name: name!,
    description: description!,
    version: version!,
    iconUrl,
    documentationUrl,
    provider,
    preferredInterface: preferredInterface!,
    additionalInterfaces,
    capabilities,
    securitySchemes,
    security,
    defaultInputModes,
    defaultOutputModes,
    skills,
    supportsAuthenticatedExtendedCard: c.supportsAuthenticatedExtendedCard,
    signatures: c.signatures
  };

  return card;
}

function isProbablyUrl(v?: string): boolean {
  return !!v && /^(https?:)?\/\//.test(v);
}

function inferPreferredInterface(spec: AgentSpec): { url: string; transport: Transport } | undefined {
  // Heuristic: if api endpoints exist, assume HTTP+JSON at a base URL root (user should override).
  // You can set A2A.card.preferredInterface explicitly for precision.
  const hasApi = !!spec.api?.endpoints?.length;
  if (hasApi) {
    // Try to guess a base; fallback to root.
    return { url: "/", transport: "HTTP+JSON" };
  }
  return undefined;
}

function deriveSkills(spec: AgentSpec): AgentCard["skills"] {
  const tags = spec.persona?.topics ?? [];
  const skills: AgentCard["skills"] = [];

  // From API endpoints
  for (const e of spec.api?.endpoints ?? []) {
    const id = `api:${e.name}`;
    const description = `HTTP ${e.method} ${e.path}`;
    skills.push({
      id,
      name: e.name,
      description,
      tags,
      inputModes: e.contentTypes ?? ["application/json"],
      outputModes: ["application/json"]
    });
  }

  // From MCP tools
  for (const t of spec.tools ?? []) {
    const id = `tool:${t.mcp?.serverRef?.urn ?? t.mcp?.serverRef?.uuid ?? t.name}`;
    const description = t.description ?? `Tool ${t.mcp.toolName} via MCP`;
    skills.push({
      id,
      name: t.name,
      description,
      tags,
      inputModes: ["application/json"],
      outputModes: ["application/json"]
    });
  }

  return skills;
}