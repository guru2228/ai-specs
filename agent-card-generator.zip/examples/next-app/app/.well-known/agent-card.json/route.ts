export const runtime = "nodejs";
import { NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import YAML from "yaml";
import { generateAgentCardFromSpec } from "@sage/agent-card-generator";

export async function GET() {
  try {
    const path = process.env.AGENT_SPEC_PATH || process.cwd() + "/config/agent.yaml";
    const raw = await readFile(path, "utf8");
    const crd = YAML.parse(raw);
    const card = generateAgentCardFromSpec(crd.spec ?? crd, { strict: true });
    return new NextResponse(JSON.stringify(card), {
      headers: {
        "content-type": "application/json",
        "cache-control": "public, max-age=300, stale-while-revalidate=86400"
      }
    });
  } catch (err: any) {
    return new NextResponse(JSON.stringify({ error: err?.message || "failed to generate agent card" }), { status: 500 });
  }
}