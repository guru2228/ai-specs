# Contributing to the AI Platform Specifications

First off, thank you for considering contributing! AI Platform Specifications are a community effort, and every contribution—from fixing a typo to proposing a new specification—helps make it better for all of us.

This document provides a set of guidelines for contributing to the AI Platform Specifications. Following them helps us keep the repository organized and ensures that we can review and integrate your changes efficiently.

## 📜 Code of Conduct

This project and everyone participating in it is governed by a Optum's Code of Conduct. By participating, you are expected to uphold this code. Please report unacceptable behavior to the Sage AI Platform Architecture team. We are committed to fostering a welcoming and respectful environment.

---

## 🤔 How Can I Contribute?

There are many ways to contribute to the AI Platform Specification, and not all of them involve writing specs.

* **🐛 Report Bugs**: If you find a typo, an error in an example, or a flaw in a specification, please create a new issue.
* **💡 Suggest Enhancements**: If you have an idea for a new feature in a spec, a new example use case, or a better way to organize the documentation, please create a new issue to start a discussion.
* **✍️ Improve Documentation**: Our guides and documentation are the front door to this AI Platform Specification. If you see an opportunity to make them clearer or more comprehensive, we welcome your edits.
* **✨ Add an Example**: Have you built an agent or workflow for a use case that isn't represented in our `examples/` directory? Share it with the community!
* **📝 Write a Prompt Template**: If you've crafted a high-quality, reusable prompt using POML, add it to our `prompts/` library.

---

## 🚀 Your First Contribution

Unsure where to begin? A great way to start is by looking for opportunities to improve the documentation or by adding an example from one of your own projects. These contributions are incredibly valuable and provide a great way to get familiar with our workflow.

### **Contribution Workflow**

We use a standard Fork & Pull Request model for all contributions.

1.  **Fork the Repository**: Start by forking the main `ai-specs` repository to your own GitHub account.
2.  **Clone Your Fork**: Clone your forked repository to your local machine:
    ```bash
    git clone [https://github.com/YOUR_USERNAME/ai-specs.git](https://github.com/YOUR_USERNAME/ai-specs.git)
    ```
3.  **Create a Branch**: Create a new branch for your changes. Use a descriptive name that summarizes your contribution.
    ```bash
    # For a new feature
    git checkout -b feature/add-new-knowledgebase-type

    # For a bug fix or typo
    git checkout -b fix/correct-typo-in-agent-guide
    ```
4.  **Make Your Changes**: Make your desired changes to the files. Be sure to follow the style guides below.
5.  **Commit Your Changes**: Commit your changes with a clear and concise commit message.
    ```bash
    git commit -m "feat(spec): Add support for Redis as a Knowledge Base type"
    ```
6.  **Push to Your Fork**: Push your branch to your forked repository on GitHub.
    ```bash
    git push origin feature/add-new-knowledgebase-type
    ```
7.  **Open a Pull Request**: Go to the original repository and you will see a prompt to open a Pull Request from your new branch. Fill out the PR template with a detailed description of your changes.

### **Pull Request Guidelines**

* **Clear Title**: The title should be a brief, one-line summary of the change.
* **Detailed Description**: In the description, explain the "why" and "what" of your contribution. If it resolves an existing issue, be sure to link it (e.g., `Resolves #123`).
* **CI Checks**: All pull requests must pass the automated CI checks (e.g., YAML linting).
* **Keep it Focused**: A pull request should address a single concern. For multiple unrelated changes, please open separate pull requests.

---

##  Style Guides

### **Specification (CRD) Changes**

Changes to the schemas in the `/specs` directory are the most impactful.

* **Start with an Issue**: Before writing any code, please open an issue to propose the change and discuss it with the maintainers.
* **Maintain Backward Compatibility**: We must be mindful of breaking changes. Any change that removes or renames an existing field must be carefully planned and versioned.
* **Document Everything**: Every new field must have a clear `description`.

### **Documentation and Guides**

* Write in clear, simple language.
* Use Markdown for formatting.
* Check for spelling and grammar mistakes.

### **Examples**

* Add new examples in a dedicated folder under `/examples/<use-case>/`.
* Your example YAML should be complete, well-commented, and runnable.
* Include a `README.md` file within your example folder that explains the use case and how the agents and workflow are designed to solve it.

### **POML Prompts**

* Place new prompts in the appropriate domain folder under `/prompts/poml/`.
* Ensure the prompt is generic and reusable. Avoid hardcoding information specific to a single, narrow use case.
* Add comments within the POML file to explain the purpose of different sections.
