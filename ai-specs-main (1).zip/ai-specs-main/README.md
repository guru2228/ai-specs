# AI Platform - AI Specs

Welcome to the official repository for Optum's AI Platform - AI Specs. This is the single source of truth for the specifications, guides, examples, and tools that enables our engineering teams to build, deploy, and manage AI agents and workflows in a standardized, secure, and scalable way.

## 🚀 Mission

Our mission is to empower developers to treat AI/ML systems as code. By defining agents, workflows, and their dependencies in declarative YAML, we accelerate development, enhance security, and bring the full power of GitOps and modern CI/CD practices to our AI ecosystem.

---

## Core Philosophy

This specification is built on a few key principles:

* **Configuration as Code**: Agent behaviors, toolsets, and workflow logic are defined in version-controlled YAML files, not hidden inside application code. This makes our AI systems auditable, repeatable, and easy to manage.
* **Portability**: We use a framework-agnostic specification. An agent or workflow defined here can be executed by any compatible runtime, preventing vendor lock-in and promoting a consistent developer experience.
* **Security by Design**: All secrets and credentials are managed through a centralized provider (Azure Key Vault) and referenced by name, never stored in plain text.
* **Community Driven**: This repository is a living project. We encourage contributions to our library of examples, prompt templates, and specifications.

---

## 🗺️ What's Inside This Repository?

| Directory | Description |
| :--- | :--- |
| **`/specs`** | The **source of truth**. Contains the formal Kubernetes Custom Resource Definition (CRD) schemas for all our AI resources (`Agent`, `AgentWorkflow`, `RAGPipeline`, etc.). |
| **`/docs`** | All human-readable documentation. If you're new here, **start with the `guides`**. You'll also find architecture decision records (ADRs) and concept explanations. |
| **`/examples`** | Practical, real-world examples of our specs in action. Organized by business use case (e.g., Utilization Management, Care Management) to provide a starting point for your projects. |
| **`/prompts`** | A centralized, reusable library of high-quality prompt templates written in Microsoft's Prompt Orchestration Markup Language (POML). |

---

## 🏁 Getting Started

Ready to build your first agent? Follow these steps:

1.  **Read the Guides**: Start by reading the developer guides in the `/docs/guides` directory.
    * [**Agent Specification Guide**](./docs/guides/01-agent-spec-guide.md)
    * [**Agent Workflow Guide**](./docs/guides/02-agent-workflow-guide.md)
2.  **Explore the Examples**: Find a use case in the `/examples` directory that is similar to your project and use it as a reference.
3.  **Define Your Agent**: Create your own `agent.yaml` or `agentworkflow.yaml` file based on the specifications and examples.
4.  **Deploy**: Follow your team's standard GitOps procedures to deploy your agent definition to the Azure Kubernetes or any Kubernetes cluster.

---

## 🙌 How to Contribute

This specification is built for and by our engineering community. Whether you're fixing a typo, adding a new example, or proposing a change to a specification, your contributions are welcome.

Please read our [**CONTRIBUTING.md**](./CONTRIBUTING.md) file to learn about our development process, coding standards, and how to submit a pull request.

---

## 💬 Support

If you have questions, encounter issues, or need guidance, please contact the **Sage - AI Platform Architecture** team.
