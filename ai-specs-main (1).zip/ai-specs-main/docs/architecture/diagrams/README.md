This directory will contain architecture diagrams. Binary image files are excluded from the repository.
